import React from "react";
import "./Footer.css";
import "../z photo/abc.png";
import imgg from "../z photo/abc.png";
export const Footer = () => {
  return (
    <div className="align footer">
      <img src={imgg} className="images" alt="logo" />
      <a
        href="http://hello@boxbrownie.com"
        target="_blank"
        rel="noopener noreferrer"
        className="links"
      >
        hello@boxbrownie.com
      </a>
      <span className="whi"> |</span>{" "}
      <a
        href="https://www.boxbrownie.com/"
        target="_blank"
        rel="noopener noreferrer"
        className="links"
      >
        https://www.boxbrownie.com/
      </a>
      <p className="whi">View boxbrownie privacy policy</p>
    </div>
  );
};
