import React from "react";
import img1 from "../z photo/img11.png";
import img2 from "../z photo/img22.png";
import img3 from "../z photo/img33.png";
import "./Datatext.css";
export const Datatext = () => {
  return (
    <div className="container ">
      <div className="row align align-items-center">
        <div className="col-md-3 offset-md-1  col-lg-3 offset-lg-1 ">
          <img className="imagesize" src={img1} alt="camera icon" />
          <h5>PHOTO-REALISTIC RENDERS.</h5>
          <p>
            Make your realestate marketing pop with realistic renders. So real
            you can't tell the difference when compared to photo
          </p>
        </div>
        <div className="col-md-3 offset-md-1 col-lg-3 offset-lg-1">
          <img className="imagesize" src={img2} alt="camera icon" />
          <h5>FAST TURNAROUND</h5>
          <p>
            Make your realestate marketing pop with realistic renders. So real
            you can't tell the difference when compared to photo
          </p>
        </div>
        <div className="col-md-3 offset-md-1 col-lg-3 offset-lg-1">
          <img className="imagesize" src={img3} alt="camera icon" />
          <h5>PRICING FROM ONLY $280</h5>
          <p>
            Make your realestate marketing pop with realistic renders. So real
            you can't tell the difference when compared to photo
          </p>
        </div>
      </div>
    </div>
  );
};
