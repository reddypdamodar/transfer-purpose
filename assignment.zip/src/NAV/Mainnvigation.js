import React from "react";
import { Link } from "react-router-dom";
import "./Main.css";

export const Mainnvigation = () => {
  return (
    <nav className="navbar navbar-expand-md navbar-light bg-light">
      <div className="container-fluid">
        <span className="brand">
          <a
            className="navbar-brand"
            href="https://www.boxbrownie.com/b/boxbrowniecom-listing-visual-marketing-analysis"
          >
            <img
              src="https://d1dbtne32ilur4.cloudfront.net/img/logoDomain2018.svg"
              alt=""
              width="35%"
              height="auto"
              className="d-inline-block align-text-top image"
            ></img>
          </a>
        </span>
        <span>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
        </span>
        <div
          className="collapse navbar-collapse  justify-content-end "
          id="navbarSupportedContent"
        >
          <ul className="navbar-nav justify-content-sm-center flex-sm-row links">
            {/* //me-auto mb-2 mb-lg-0" */}
            {/* <li className="nav-item">
              <Link className="nav-link active" aria-current="page" to={"/"}>
                HOME
              </Link>
            </li> */}
            <li className="nav-item ">
              <Link
                className="nav-link  active p-2"
                aria-current="page"
                to={"/blog"}
              >
                BLOG
              </Link>
            </li>{" "}
            <li className="nav-item ">
              <Link
                className="nav-link active p-2"
                aria-current="page"
                to={"/about"}
              >
                ABOUT
              </Link>
            </li>
            <li className="nav-item ">
              <Link
                className="nav-link active p-2"
                aria-current="page"
                to={"/contact"}
              >
                CONTACT
              </Link>
            </li>{" "}
            <li className="nav-item ">
              <Link
                className="nav-link active p-2"
                aria-current="page"
                to={"/gallery"}
              >
                GALLERY
              </Link>
            </li>{" "}
            <li className="nav-item ">
              <Link
                className="nav-link active p-2"
                aria-current="page"
                to={"/resources"}
              >
                RESOURCES
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};
//https://d1dbtne32ilur4.cloudfront.net/img/logoDomain2018.svg
