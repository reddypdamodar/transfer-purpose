import "./App.css";
import { Root } from "./Pages/Root";
import { Home } from "./Pages/Home";
import { ABOUT } from "./Pages/ABOUT";
//import { BLOG } from "./Pages/BLOG";
import { Contact } from "./Pages/Contact";
import { Resources } from "./Pages/Resources";
import { Gallery } from "./Pages/Gallery";
import { createBrowserRouter, RouterProvider } from "react-router-dom";

const router = createBrowserRouter([
  {
    path: "/",
    element: <Root />,
    children: [
      { path: "/", element: <Home /> },
      { path: "/about", element: <ABOUT /> },
      { path: "/blog", element: <Home /> },
      { path: "/contact", element: <Contact /> },
      { path: "/resources", element: <Resources /> },
      { path: "/gallery", element: <Gallery /> },
    ],
  },
]);
function App() {
  return (
    <div>
      <RouterProvider router={router} />
    </div>
  );
}

export default App;
