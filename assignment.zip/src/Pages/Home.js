import { useState } from "react";
import React from "react";
import "./home.css";
export const Home = () => {
  const [firstname, setfirstname] = useState("");
  const [fnamevalid, setfnamevalid] = useState("");
  const [lastname, setlastname] = useState("");
  const [lnamevalid, setlnamevalid] = useState("");
  const [email, setemail] = useState("");
  const [country, setcountry] = useState("");
  const [phone, setphone] = useState("");
  const [description, setdescription] = useState("");
  const namehandler = (e) => {
    setfirstname(e.target.value);
    if (firstname.trim() >= 6) {
      setfnamevalid(true);
      return;
    }
  };
  const lnamehandler = (e) => {
    lastname(e.target.value);
    if (firstname.trim() >= 6) {
      setlnamevalid(true);
      return;
    }
  };
  return (
    <div className="backPhoto ">
      <div className="container">
        <div className="row">
          <h1 className="para col-lg-5 col-md-5">
            Photo realistic real estate renders from only{" "}
            <span className="redd">$280</span>{" "}
          </h1>

          <form className="form col-lg-4 col-md-4" action="">
            <h3 className="quote top">Free Quote</h3>
            <p className="quote">
              Enter your info below we will send you a free quote for your
              project
            </p>
            <input
              defaultValue={"First name"}
              className="name"
              type="text"
              onChange={namehandler}
              //   value={firstname}
            />
            <input
              defaultValue={"Last name"}
              className="name"
              type="text"
              onChange={lnamehandler}
              //   value={lastname}
            />
            <input
              defaultValue={"Email address"}
              className="other"
              type="text"
              //   value={email}
            />
            <input
              defaultValue={"Country"}
              className="other"
              type="text"
              //   value={country}
            />
            <input
              defaultValue={"Phone number"}
              className="other"
              type="text"
              //   value={phone}
            />
            <textarea
              rows={3}
              defaultValue={"Description of project"}
              className="other"
              type="text"
              //   value={description}
            />
            <button className="other redbutton" type="submit">
              Request a free quote
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
