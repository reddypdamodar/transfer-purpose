import React from "react";
import { Outlet } from "react-router-dom";
import { Mainnvigation } from "../NAV/Mainnvigation";
import { Datatext } from "../NAV/Datatext";
import { Carasol } from "../NAV/Carasol";
import { Footer } from "../NAV/Footer";

export const Root = () => {
  return (
    <div>
      <Mainnvigation />
      <main>
        <Outlet />
      </main>
      <Datatext />
      <Carasol />
      <Footer />
    </div>
  );
};
