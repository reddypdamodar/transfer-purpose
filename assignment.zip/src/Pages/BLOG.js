import React from "react";

export const BLOG = () => {
  return <div>BLOG</div>;
};
