import React from "react";

export const ABOUT = () => {
  return <div>ABOUT</div>;
};
