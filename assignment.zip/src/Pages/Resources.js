import React from "react";

export const Resources = () => {
  return <div>Resources</div>;
};
